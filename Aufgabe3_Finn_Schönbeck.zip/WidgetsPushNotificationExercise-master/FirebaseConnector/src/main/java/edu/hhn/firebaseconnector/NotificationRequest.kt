package edu.hhn.firebaseconnector

data class NotificationRequest(
    val title: String,
    val message: String,
)
