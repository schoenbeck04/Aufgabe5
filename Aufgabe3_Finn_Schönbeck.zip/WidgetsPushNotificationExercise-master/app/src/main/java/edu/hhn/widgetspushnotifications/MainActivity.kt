package edu.hhn.widgetspushnotifications

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import edu.hhn.widgetspushnotifications.CounterViewModelInstance
import edu.hhn.widgetspushnotifications.MessageViewModel
import edu.hhn.widgetspushnotifications.ui.theme.BroadcastAppTheme
import androidx.lifecycle.viewmodel.compose.viewModel

/**
 * Hauptaktivität der App.
 * Diese Aktivität hostet das Benutzerinterface und zeigt den aktuellen Zählerstand
 * sowie ein Eingabefeld und einen Senden-Button an.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

                // Setzt das Composable UI für die App.
                setContent {
            BroadcastAppTheme {
                MainScreen()
            }
        }
    }
}

/**
 * Hauptbildschirm der Anwendung.
 * Zeigt den aktuellen Zählerstand an und bietet ein Eingabefeld für Benutzernachrichten sowie einen Button zum Senden.
 *
 * @param viewModel ViewModel für die Verwaltung der Broadcast-Nachrichten.
 */
@Composable
fun MainScreen(viewModel: MessageViewModel = viewModel()) {
    // Zustand für Benutzereingaben
    var userInput by remember { mutableStateOf("") }

    // Instanz des CounterViewModels
    val counterViewModel = CounterViewModelInstance.instance

    // Beobachtet Änderungen am Zählerwert (LiveData)
    val count by counterViewModel.count.observeAsState(0)

    // Layout der App
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Überschrift der App
        Text(
            text = "Broadcaster",
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Anzeige des aktuellen Zählerstands
        Text(
            text = "Current Count: $count",
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Eingabefeld für Benutzernachrichten
        OutlinedTextField(
            value = userInput,
            onValueChange = { userInput = it },
            label = { Text("Enter your text here") },
            textStyle = androidx.compose.ui.text.TextStyle(
                color = Color.Black, // Textfarbe Schwarz
                fontSize = 16.sp    // Schriftgröße
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Button zum Senden der Nachricht
        Button(
            onClick = {
                // Übermittelt die Nachricht, wenn der Button geklickt wird
                viewModel.sendBroadcast(userInput)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Send")
        }
    }
}
