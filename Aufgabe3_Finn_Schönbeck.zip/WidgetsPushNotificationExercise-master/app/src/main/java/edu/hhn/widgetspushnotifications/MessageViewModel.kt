package edu.hhn.widgetspushnotifications

import android.util.Log
import edu.hhn.firebaseconnector.NotificationHelper
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch


class MessageViewModel : ViewModel() {
    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message

    fun updateMessage(newMessage: String) {
        _message.value = newMessage
    }
    fun sendBroadcast(message: String) {

        viewModelScope.launch {
            try {


                // Send the notification asynchronously
                NotificationHelper.sendNotification("Broadcaster: Finn", message) { success, result ->
                    if (success) {
                    Log.d("Backend-Callback","Message Send Successfully")
                    } else {
                        Log.d("Backend-Callback","Message send failed")
                    }
                }
            } catch (e: Exception) {
                Log.e("Backend-Callback","Error: ${e.localizedMessage}",e)
            }
        }
    }
}

