package edu.hhn.widgetspushnotifications.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun BroadcastAppTheme(
    darkTheme: Boolean = false, // optionaler Parameter für dunklen Modus
    content: @Composable () -> Unit
) {
    // Wähle das Thema basierend auf dem "darkTheme"-Flag
    val colors = if (darkTheme) {
        darkColorScheme(
            primary = DarkPrimary,
            secondary = DarkSecondary,
            background = DarkBackground,
            surface = DarkSurface,
            onPrimary = DarkOnPrimary,
            onSecondary = DarkOnSecondary,
            onBackground = DarkOnBackground,
            onSurface = DarkOnSurface
        )
    } else {
        lightColorScheme(
            primary = LightPrimary,
            secondary = LightSecondary,
            background = LightBackground,
            surface = LightSurface,
            onPrimary = LightOnPrimary,
            onSecondary = LightOnSecondary,
            onBackground = LightOnBackground,
            onSurface = LightOnSurface
        )
    }

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}

// Optional: Vorschau für das Thema
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    BroadcastAppTheme {
        // Hier kannst du einen Beispieltext oder UI-Elemente anzeigen
        androidx.compose.material3.Text("Hello, Broadcast App!")
    }
}
