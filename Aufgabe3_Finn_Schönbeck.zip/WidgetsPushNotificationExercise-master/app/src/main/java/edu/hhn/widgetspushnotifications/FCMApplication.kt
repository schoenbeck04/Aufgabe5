package edu.hhn.widgetspushnotifications

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging

/**
 * Die Hauptanwendungsklasse für die Firebase Cloud Messaging (FCM)-Integration.
 * Initialisiert Firebase und abonniert das Gerät für ein Thema.
 */
class FCMApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Firebase-Initialisierung
        FirebaseApp.initializeApp(this)

        try {
            // Abonniert das Gerät für das Thema "broadcast", um Nachrichten zu empfangen.
            FirebaseMessaging.getInstance().subscribeToTopic("broadcast")
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Erfolgreiches Abonnement
                        Log.d("FCM", "Thema erfolgreich abonniert.")
                    } else {
                        // Fehler beim Abonnement, Details im Log
                        Log.e("FCM", "Thema-Abonnement fehlgeschlagen.", task.exception)
                    }
                }
        } catch (e: Exception) {
            // Unerwarteter Fehler während des Abonnementprozesses
            Log.e("FCM", "Fehler beim FCM-Abonnement.", e)
        }
    }
}
