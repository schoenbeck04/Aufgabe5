package edu.hhn.widgetspushnotifications.FCMService

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import android.util.Log

/**
 * Verwaltet Firebase Cloud Messaging (FCM)-Operationen und zeigt Benachrichtigungen an.
 * Erweitert FirebaseMessagingService, um eingehende Nachrichten und Token-Updates zu verarbeiten.
 */
class FCMService : FirebaseMessagingService() {

    /**
     * Verarbeitet eingehende FCM-Nachrichten.
     * Unterstützt sowohl Daten- als auch Benachrichtigungsinhalte.
     *
     * @param remoteMessage Die empfangene FCM-Nachricht.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        try {
            // Verarbeite die Daten-Payload
            remoteMessage.data.takeIf { it.isNotEmpty() }?.let {
                Log.i("FCMService", "Dateninhalt empfangen: ${it["key"]}")
            } ?: Log.w("FCMService", "Leerer Dateninhalt empfangen.")

            // Verarbeite die Benachrichtigungs-Payload
            remoteMessage.notification?.let {
                Log.i("FCMService", "Benachrichtigung empfangen: Titel=${it.title}, Inhalt=${it.body}")
                zeigeBenachrichtigung(it.title, it.body)
            } ?: Log.w("FCMService", "Keine Benachrichtigungs-Payload empfangen.")
        } catch (e: Exception) {
            Log.e("FCMService", "Fehler beim Verarbeiten der Nachricht: ${e.localizedMessage}")
        }
    }

    /**
     * Verarbeitet neue oder aktualisierte FCM-Tokens.
     *
     * @param token Das neue FCM-Token.
     */
    override fun onNewToken(token: String) {
        try {
            Log.i("FCMService", "Neues FCM-Token empfangen: $token")
            // TODO: Sende das Token an den Server, falls erforderlich
        } catch (e: Exception) {
            Log.e("FCMService", "Fehler beim Verarbeiten des Tokens: ${e.localizedMessage}")
        }
    }

    /**
     * Zeigt eine Benachrichtigung mit dem gegebenen Titel und Inhalt an.
     *
     * @param title Der Titel der Benachrichtigung.
     * @param body Der Inhalt der Benachrichtigung.
     */
    private fun zeigeBenachrichtigung(title: String?, body: String?) {
        try {
            val benachrichtigungsManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val kanalId = "default_channel"

            // Erstelle einen Benachrichtigungskanal für Android 8+ (Oreo und höher)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val kanal = NotificationChannel(kanalId, "Standardkanal", NotificationManager.IMPORTANCE_HIGH)
                benachrichtigungsManager.createNotificationChannel(kanal)
            }

            // Erstelle und zeige die Benachrichtigung
            val benachrichtigung = NotificationCompat.Builder(this, kanalId)
                .setContentTitle(title ?: "Keine Titelangabe")
                .setContentText(body ?: "Keine Inhaltsangabe")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()

            benachrichtigungsManager.notify(0, benachrichtigung)
        } catch (e: Exception) {
            Log.e("FCMService", "Fehler beim Anzeigen der Benachrichtigung: ${e.localizedMessage}")
        }
    }
}
