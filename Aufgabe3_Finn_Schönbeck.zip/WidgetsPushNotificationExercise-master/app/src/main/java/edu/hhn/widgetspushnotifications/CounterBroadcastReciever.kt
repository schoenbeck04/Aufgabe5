package edu.hhn.widgetspushnotifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CounterBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "edu.hhn.widgetspushnotifications.SEND_COUNTER") {
            val counter_value = intent.getIntExtra("counter_value", 0)
            CounterViewModelInstance.instance.updateCount(counter_value)
        }
    }
}


