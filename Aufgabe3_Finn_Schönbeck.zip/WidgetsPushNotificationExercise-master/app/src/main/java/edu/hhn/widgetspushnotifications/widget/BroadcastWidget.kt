package edu.hhn.widgetspushnotifications.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.glance.*
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

object BroadcastWidget : GlanceAppWidget() {
    val countKey = intPreferencesKey("count")

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            WidgetContent(
                count = currentState(key = countKey) ?: 0
            )
        }
    }
}

@Composable
fun WidgetContent(count: Int) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(Color.Gray))
            .padding(16.dp),
        verticalAlignment = Alignment.Vertical.CenterVertically,
        horizontalAlignment = Alignment.Horizontal.CenterHorizontally
    ) {
        Text(
            text = "Current count: $count",
            style = TextStyle(
                color = ColorProvider(Color.White),
                fontSize = 16.sp
            )
        )

        Spacer(modifier = GlanceModifier.height(16.dp))

        Row {
            Button(
                text = "Inc",
                onClick = actionRunCallback<IncrementActionCallback>()
            )
            Spacer(modifier = GlanceModifier.width(8.dp))
            Button(
                text = "Dec",
                onClick = actionRunCallback<DecrementActionCallback>()
            )
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        Button(
            text = "Send",
            onClick = actionRunCallback<SendCounterActionCallback>()
        )
    }
}
class IncrementActionCallback : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val sharedPreferences = context.getSharedPreferences("widget_preferences", Context.MODE_PRIVATE)
        val safeCount = sharedPreferences.getInt("counter_value",0)

        sharedPreferences.edit().putInt("counter_value",safeCount+1).apply()

        updateAppWidgetState(context, glanceId){state ->
            state[BroadcastWidget.countKey] = safeCount+1
        }
        BroadcastWidget.update(context, glanceId)
    }
}

class DecrementActionCallback : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        updateAppWidgetState(context, glanceId) { prefs ->
            val currentCount = prefs[BroadcastWidget.countKey] ?: 0
            if (currentCount > 0) prefs[BroadcastWidget.countKey] = currentCount - 1
        }
        BroadcastWidget.update(context, glanceId)
    }
}

class SendCounterActionCallback : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        // Aktuellen Zählerstand auslesen
        var currentCount = 0
        updateAppWidgetState(context, glanceId) { prefs ->
            currentCount = prefs[BroadcastWidget.countKey] ?: 0
        }

        // Broadcast senden
        val intent = Intent("com.example.broadcastapp.UPDATE_COUNTER").apply {
            putExtra("counter_value", currentCount)
        }
        context.sendBroadcast(intent)
    }
}
class WidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget
        get() = BroadcastWidget
}

